import requests
import os

VLLM_URL = os.getenv("VLLM_URL", "http://localhost:3000/generate")
PROMPT_TEMPLATE_PATH = "prompt_templates/polite_negotiation_prompt.txt"

def load_prompt_template():
    with open(PROMPT_TEMPLATE_PATH, "r") as f:
        return f.read()

def llm_negotiation_message(conflict_details, model="vllm"):
    """
    Calls the LLM endpoint with a formatted prompt and returns a polite negotiation message.
    """
    prompt_template = load_prompt_template()
    prompt = prompt_template.format(**conflict_details)
    if model == "openai":
        # Add OpenAI API call here if needed
        raise NotImplementedError("OpenAI integration not implemented in this template.")
    else:
        try:
            response = requests.post(
                VLLM_URL,
                json={"prompt": prompt, "max_tokens": 120}
            )
            response.raise_for_status()
            return response.json().get("text", "").strip()
        except Exception as e:
            return "Sorry, we couldn't generate a negotiation message at this time." 